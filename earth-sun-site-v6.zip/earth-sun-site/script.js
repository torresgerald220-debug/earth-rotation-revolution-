/* Earth & Sun
 * - The Earth orbits the Sun nonstop.
 * - Click the Earth: it slowly stops orbiting, the view zooms in a little,
 *   and the Sun's light turns off. Click the Earth again to zoom out and
 *   keep orbiting.
 * - Click the Sun: the light turns ON / OFF at any time (no text shown).
 */

/* ---------- Sharp Sun texture (drawn in code so it stays crisp when big) ---------- */
function makeSunTexture(size) {
  const c = document.createElement('canvas');
  c.width = c.height = size;
  const g = c.getContext('2d');
  const m = size / 2;
  const R = m - 1;

  let seed = 987654;
  const rnd = () => (seed = (seed * 16807) % 2147483647) / 2147483647;

  g.save();
  g.beginPath();
  g.arc(m, m, R, 0, Math.PI * 2);
  g.clip();

  // glowing base: white-yellow centre to orange edge
  const base = g.createRadialGradient(m, m, 0, m, m, R);
  base.addColorStop(0, '#fffbe2');
  base.addColorStop(0.45, '#ffe071');
  base.addColorStop(0.8, '#ffab24');
  base.addColorStop(1, '#f0720c');
  g.fillStyle = base;
  g.fillRect(0, 0, size, size);

  // surface granulation: lots of small bright and dark cells
  for (let i = 0; i < 5200; i++) {
    const a = rnd() * Math.PI * 2;
    const d = Math.sqrt(rnd()) * R;
    const x = m + Math.cos(a) * d, y = m + Math.sin(a) * d;
    const r = size * (0.006 + rnd() * 0.02);
    const bright = rnd() < 0.5;
    const grad = g.createRadialGradient(x, y, 0, x, y, r);
    grad.addColorStop(0, bright ? 'rgba(255,246,170,.45)' : 'rgba(205,80,0,.38)');
    grad.addColorStop(1, bright ? 'rgba(255,246,170,0)' : 'rgba(205,80,0,0)');
    g.fillStyle = grad;
    g.beginPath(); g.arc(x, y, r, 0, Math.PI * 2); g.fill();
  }

  // limb darkening: edges slightly darker so it reads as a sphere
  const limb = g.createRadialGradient(m, m, R * 0.55, m, m, R);
  limb.addColorStop(0, 'rgba(120,30,0,0)');
  limb.addColorStop(1, 'rgba(120,30,0,.5)');
  g.fillStyle = limb;
  g.fillRect(0, 0, size, size);
  g.restore();

  return c.toDataURL('image/png');
}
try { sunImg.src = makeSunTexture(700); } catch (e) { /* keeps assets/sun.png */ }

const space = document.getElementById('space');
const earth = document.getElementById('earth');
const sun = document.getElementById('sun');
const sunImg = document.getElementById('sunImg');
const orbitLine = document.getElementById('orbitLine');
const orbitGlow = document.getElementById('orbitGlow');
const starsCanvas = document.getElementById('stars');

const ORBIT_SECONDS = 26;     // time for one full trip around the Sun
const TILT_DEG = -8;          // slight tilt of the orbit, like the image

let angle = Math.PI * 0.08;   // start near the right side, like the image
let speed = 1;                // 1 = orbiting, 0 = stopped (eased)
let targetSpeed = 1;
let focused = false;
let W = 0, H = 0, rx = 0, ry = 0;

/* ---------- Lights ---------- */
function setLights(on) {
  document.body.classList.toggle('lights-on', on);
  document.body.classList.toggle('lights-off', !on);
  sun.setAttribute('aria-pressed', on ? 'true' : 'false');
}
function lightsAreOn() { return document.body.classList.contains('lights-on'); }

sun.addEventListener('click', () => setLights(!lightsAreOn()));

/* ---------- Earth click: stop + slow zoom + Sun off ---------- */
const ZOOM_MAX = 1.3;     // only a little zoom, so the Sun stays in view
const ZOOM_MARGIN = 36;   // px kept free around the Earth and the Sun
let zoomTimer = null;

// Zoom a little toward the Earth while keeping the Sun fully on screen.
function zoomFrame() {
  const e = earth.getBoundingClientRect();
  const s = sun.getBoundingClientRect();
  const ecx = e.left + e.width / 2,  ecy = e.top + e.height / 2;
  const scx = s.left + s.width / 2,  scy = s.top + s.height / 2;
  const er = e.width / 2, sr = s.width / 2;

  // box that holds both the Earth and the Sun
  const left   = Math.min(ecx - er, scx - sr);
  const right  = Math.max(ecx + er, scx + sr);
  const top    = Math.min(ecy - er, scy - sr);
  const bottom = Math.max(ecy + er, scy + sr);
  const bx = (left + right) / 2, by = (top + bottom) / 2;
  const hw = (right - left) / 2,  hh = (bottom - top) / 2;

  // largest zoom (up to ZOOM_MAX) that still fits both with a margin
  const fit = Math.min((W / 2 - ZOOM_MARGIN) / hw, (H / 2 - ZOOM_MARGIN) / hh);
  const z = Math.max(1, Math.min(ZOOM_MAX, fit));

  // centre that box on the screen, then scale
  const tx = -z * (bx - W / 2);
  const ty = -z * (by - H / 2);
  return { tx, ty, z };
}

earth.addEventListener('click', () => {
  focused = !focused;
  clearTimeout(zoomTimer);
  if (focused) {
    setLights(false);       // the Sun's light turns off
    targetSpeed = 0;        // the Earth stops going around the Sun
    // wait a moment for the Earth to settle, then zoom slowly (a little)
    zoomTimer = setTimeout(() => {
      const f = zoomFrame();
      space.style.transformOrigin = '50% 50%';
      space.style.transform = 'translate(' + f.tx + 'px,' + f.ty + 'px) scale(' + f.z + ')';
    }, 900);
  } else {
    space.style.transform = 'translate(0px,0px) scale(1)';
    targetSpeed = 1;
  }
});

/* ---------- Layout ---------- */
function layout() {
  W = window.innerWidth;
  H = window.innerHeight;
  rx = Math.min(W * 0.40, H * 0.62 * (W / H > 1 ? 1.5 : 1));
  rx = Math.min(rx, W * 0.42);
  ry = Math.min(H * 0.27, rx * 0.5);

  for (const el of [orbitLine, orbitGlow]) {
    el.setAttribute('cx', W / 2);
    el.setAttribute('cy', H / 2);
    el.setAttribute('rx', rx);
    el.setAttribute('ry', ry);
    el.setAttribute('transform', 'rotate(' + TILT_DEG + ' ' + W / 2 + ' ' + H / 2 + ')');
  }
  drawStars();
}

/* ---------- Starfield ---------- */
function drawStars() {
  const dpr = window.devicePixelRatio || 1;
  starsCanvas.width = W * dpr;
  starsCanvas.height = H * dpr;
  const g = starsCanvas.getContext('2d');
  g.setTransform(dpr, 0, 0, dpr, 0, 0);

  const bg = g.createLinearGradient(0, 0, W, H);
  bg.addColorStop(0, '#0a0c1c');
  bg.addColorStop(1, '#02030a');
  g.fillStyle = bg;
  g.fillRect(0, 0, W, H);

  // soft blue haze patches (like the original picture)
  for (const [x, y, r, a] of [[0.78, 0.22, 0.30, .14], [0.30, 0.78, 0.35, .10], [0.55, 0.45, 0.4, .07]]) {
    const hz = g.createRadialGradient(x * W, y * H, 0, x * W, y * H, r * Math.max(W, H));
    hz.addColorStop(0, 'rgba(60,110,230,' + a + ')');
    hz.addColorStop(1, 'rgba(60,110,230,0)');
    g.fillStyle = hz;
    g.fillRect(0, 0, W, H);
  }

  // stars (seeded so they don't jump around on resize)
  let seed = 1234567;
  const rnd = () => (seed = (seed * 16807) % 2147483647) / 2147483647;
  const count = Math.round((W * H) / 2600);
  for (let i = 0; i < count; i++) {
    const x = rnd() * W, y = rnd() * H;
    const r = rnd() < 0.06 ? 1.5 : rnd() * 0.9 + 0.2;
    g.globalAlpha = 0.25 + rnd() * 0.75;
    g.fillStyle = rnd() < 0.2 ? '#bcd4ff' : '#ffffff';
    g.beginPath();
    g.arc(x, y, r, 0, Math.PI * 2);
    g.fill();
  }
  g.globalAlpha = 1;
}

/* ---------- Animation loop ---------- */
let last = performance.now();
function frame(now) {
  const dt = Math.min((now - last) / 1000, 0.05);
  last = now;

  // ease the orbit speed so stopping / restarting is smooth
  speed += (targetSpeed - speed) * Math.min(1, dt * (focused ? 4 : 1.6));
  if (Math.abs(targetSpeed - speed) < 0.002) speed = targetSpeed;
  angle += (Math.PI * 2 / ORBIT_SECONDS) * speed * dt;

  // position on the ellipse, then tilt it
  const ex = rx * Math.cos(angle);
  const ey = ry * Math.sin(angle);
  const t = TILT_DEG * Math.PI / 180;
  const px = W / 2 + ex * Math.cos(t) - ey * Math.sin(t);
  const py = H / 2 + ex * Math.sin(t) + ey * Math.cos(t);

  // depth: a bit bigger when passing in front (bottom), smaller behind (top)
  const depth = Math.sin(angle);
  const scale = 1 + depth * 0.22;
  earth.style.transform = 'translate(' + px.toFixed(1) + 'px,' + py.toFixed(1) + 'px) scale(' + scale.toFixed(3) + ')';
  earth.style.zIndex = depth < 0 ? 5 : 15;   // behind the Sun at the back

  // Lighting: the side facing the Sun is bright, the far side is dark
  const dx = W / 2 - px, dy = H / 2 - py;                 // vector from Earth to Sun
  const len = Math.hypot(dx, dy) || 1;
  const ux = dx / len, uy = dy / len;
  const toSunCss = Math.atan2(dx, -dy) * 180 / Math.PI;   // CSS angle toward the Sun
  earth.style.setProperty('--shade-angle', (toSunCss + 180).toFixed(1) + 'deg');
  earth.style.setProperty('--lit-x', (50 + 34 * ux).toFixed(1) + '%');
  earth.style.setProperty('--lit-y', (50 + 34 * uy).toFixed(1) + '%');

  requestAnimationFrame(frame);
}

window.addEventListener('resize', layout);
layout();
requestAnimationFrame(frame);
